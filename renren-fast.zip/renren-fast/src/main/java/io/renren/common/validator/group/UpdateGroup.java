/**
 * .
 *
 * Thm
 *
 * ！
 */

package io.renren.common.validator.group;

/**
 * 更新数据 Group
 *
 * @author Mark sunlightcs@gmail.com
 */

public interface UpdateGroup {

}
