/**
 * .
 *
 * Thm
 *
 * ！
 */

package io.renren.common.validator.group;

/**
 * 阿里云
 *
 * @author Mark sunlightcs@gmail.com
 */
public interface AliyunGroup {
}
