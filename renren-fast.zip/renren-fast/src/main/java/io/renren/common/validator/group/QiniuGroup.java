/**
 * .
 *
 * Thm
 *
 * ！
 */

package io.renren.common.validator.group;

/**
 * 七牛
 *
 * @author Mark sunlightcs@gmail.com
 */
public interface QiniuGroup {
}
