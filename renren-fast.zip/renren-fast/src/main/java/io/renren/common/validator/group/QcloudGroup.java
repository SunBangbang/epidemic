/**
 * .
 *
 * Thm
 *
 * ！
 */

package io.renren.common.validator.group;

/**
 * 腾讯云
 *
 * @author Mark sunlightcs@gmail.com
 */
public interface QcloudGroup {
}
