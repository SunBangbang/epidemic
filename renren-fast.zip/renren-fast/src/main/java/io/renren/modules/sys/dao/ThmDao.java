/**
 * .
 *
 * Thm
 *
 * ！
 */

package io.renren.modules.sys.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.sys.entity.SysUserEntity;
import io.renren.modules.sys.entity.Thm;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ThmDao extends BaseMapper<Thm> {

}
