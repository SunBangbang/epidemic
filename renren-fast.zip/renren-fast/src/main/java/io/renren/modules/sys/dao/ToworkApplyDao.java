/**
 * .
 *
 * Thm
 *
 * ！
 */

package io.renren.modules.sys.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.renren.modules.sys.entity.Thm;
import io.renren.modules.sys.entity.ToworkApply;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ToworkApplyDao extends BaseMapper<ToworkApply> {

}
